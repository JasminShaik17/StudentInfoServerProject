package nareshit.andaug7am;

import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/sinfo")
public class StuInfo {
	static ArrayList<Student> list = new ArrayList<Student>( );

	@Path("/insert/{name}/{gender}/{qual}/{email}")
	@Produces(MediaType.TEXT_PLAIN)
	@GET
	public String insert(@PathParam("name") String name,
			@PathParam("gender") String gender,
			@PathParam("qual") String qual,
			@PathParam("email")String email) {
		if(name.length()>0 && gender.length()>0 
				&& qual.length()>0 && email.length()>0) {
	System.out.println(name+"\t"+gender+"\t"+qual+"\t"+email);
	  Student s = new Student( );
	  s.setName(name);
	  s.setGender(gender);
	  s.setEmail(email);
	  s.setQual(qual);
	  list.add(s);
	
			return "{\"status\":\"success\"}";
		}else {
			return "{\"status\":\"fail\"}";
		}
	}
	
	@Path("/read")
	@Produces(MediaType.TEXT_PLAIN)
	@GET
	public String read() {
		
		String response= "{\"students\":[";
		for(Student item:list) {
			response= response+"{\"name\":\""+item.getName()+"\",\"gender\":\""+item.getGender()+"\",\"qual\":\""+item.getQual()+"\",\"email\":\""+item.getEmail()+"\"},";
		}
		response= response.substring(0, response.length()-1);
		response = response+"]}";
		return response;
	}
	
}
